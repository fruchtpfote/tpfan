from __future__ import annotations
from dataclasses import dataclass, field

EPS = 0.5


@dataclass
class CurveModel:
    points: list[tuple[float, int]] = field(default_factory=list)
    t_min: float = 20.0
    t_max: float = 110.0

    def add(self, t: float, level: int) -> None:
        t = float(t)
        lvl = max(0, min(7, int(level)))
        self.points.append((t, lvl))
        self.points.sort(key=lambda p: p[0])
        idx = next(i for i, p in enumerate(self.points) if p[0] == t and p[1] == lvl)
        left = self.points[idx - 1][0] if idx > 0 else self.t_min - EPS
        right = self.points[idx + 1][0] if idx < len(self.points) - 1 else self.t_max + EPS
        if t - left < EPS or right - t < EPS:
            del self.points[idx]
            raise ValueError("point too close to neighbour")

    def remove(self, index: int) -> None:
        if len(self.points) <= 2:
            raise ValueError("curve must keep at least 2 points")
        del self.points[index]

    def move(self, index: int, t: float, level: float) -> tuple[float, int]:
        if not (0 <= index < len(self.points)):
            raise IndexError(f"index {index} out of range")
        t = max(self.t_min, min(self.t_max, float(t)))
        lvl = max(0, min(7, int(round(level))))
        left = self.points[index - 1][0] + EPS if index > 0 else self.t_min
        right = self.points[index + 1][0] - EPS if index < len(self.points) - 1 else self.t_max
        t = max(left, min(right, t))
        self.points[index] = (t, lvl)
        return self.points[index]


HIT_THRESHOLD_PX = 12

PRESETS: list[tuple[str, list[tuple[float, int]]]] = [
    ("Sehr ruhig",  [(45.0, 0), (60.0, 1), (70.0, 2), (76.0, 3),
                     (82.0, 4), (87.0, 5), (91.0, 6), (95.0, 7)]),
    ("Ruhig",       [(42.0, 0), (55.0, 1), (64.0, 2), (72.0, 3),
                     (78.0, 4), (83.0, 5), (87.0, 6), (91.0, 7)]),
    ("Ausgewogen",  [(40.0, 0), (50.0, 1), (58.0, 2), (66.0, 3),
                     (72.0, 4), (78.0, 5), (83.0, 6), (88.0, 7)]),
    ("Kühl",        [(40.0, 0), (48.0, 2), (55.0, 3), (62.0, 4),
                     (68.0, 5), (74.0, 6), (80.0, 7)]),
    ("Sehr kühl",   [(40.0, 1), (45.0, 2), (50.0, 3), (55.0, 4),
                     (60.0, 5), (65.0, 6), (70.0, 7)]),
]

_PRESET_MATCH_EPS = 0.05

_BUILTIN_NAMES = frozenset(name for name, _ in PRESETS)


def match_preset_name(points) -> str | None:
    """Liefert den Preset-Namen, falls die Punkte exakt einem PRESET entsprechen.

    Vergleicht Punktanzahl, Temperaturen (mit kleinem float-Spielraum) und
    Levels. Gibt None zurück, wenn keine Vorlage passt → manuelle Kurve.
    """
    try:
        pts = [(float(t), int(l)) for t, l in points]
    except (TypeError, ValueError):
        return None
    for name, preset in PRESETS:
        if len(preset) != len(pts):
            continue
        if all(abs(pt - rt) <= _PRESET_MATCH_EPS and pl == rl
               for (pt, pl), (rt, rl) in zip(preset, pts)):
            return name
    return None


def format_mode_label(mode: str, curve_points=None) -> str:
    """Mensch-lesbarer Modus-String inkl. Kurvenherkunft.

    'curve' wird mit '· Vorlage: <Name>' bzw. 'manuelle Kurve' ergänzt.
    Profile/Auto/Manual werden unverändert weitergereicht.
    """
    if mode == "curve":
        name = match_preset_name(curve_points or [])
        suffix = name if name else "manuelle Kurve"
        return f"curve · {suffix}"
    return str(mode)


def make_widget(model: CurveModel, on_change, parent=None,
                on_save_preset=None, on_delete_preset=None):
    """on_change(points) wird gerufen, wenn der User Apply klickt."""
    import pyqtgraph as pg
    from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
                                 QInputDialog, QMessageBox)
    from PyQt6.QtCore import Qt, QPointF, QObject, QEvent

    LEGEND_TEXT = (
        "<b>Bedienung:</b><br>"
        "• Punkt mit linker Maustaste <i>ziehen</i> → Position verschieben<br>"
        "• Linksklick auf leere Fläche → neuen Punkt hinzufügen<br>"
        "• Rechtsklick auf Punkt → Punkt entfernen<br>"
        "• <b>Anwenden</b> überträgt die Kurve an den Daemon"
    )

    class _DragFilter(QObject):
        def __init__(self, editor):
            super().__init__()
            self.editor = editor
            self.drag_idx: int | None = None

        def eventFilter(self, obj, ev):
            et = ev.type()
            if et == QEvent.Type.GraphicsSceneMousePress and ev.button() == Qt.MouseButton.LeftButton:
                idx = self.editor._hit_test(ev.scenePos())
                if idx is not None:
                    self.drag_idx = idx
                    self.editor._dragging = True
                    ev.accept()
                    return True
            elif et == QEvent.Type.GraphicsSceneMouseMove and self.drag_idx is not None:
                self.editor._drag_to(self.drag_idx, ev.scenePos())
                ev.accept()
                return True
            elif et == QEvent.Type.GraphicsSceneMouseRelease and self.drag_idx is not None:
                self.drag_idx = None
                # Drag-Flag erst nach dem nachfolgenden sigMouseClicked zurücksetzen,
                # damit der Klick nicht als "Punkt hinzufügen" interpretiert wird.
                ev.accept()
                return True
            return False

    class CurveEditor(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            lay = QVBoxLayout(self)
            self.plot = pg.PlotWidget()
            self.plot.setXRange(30, 95)
            self.plot.setYRange(0, 7)
            self.plot.setLabel("bottom", "°C")
            self.plot.setLabel("left", "Level")
            self.plot.setMouseEnabled(x=False, y=False)
            lay.addWidget(self.plot)
            self.scatter = pg.ScatterPlotItem(size=12)
            self.line = pg.PlotCurveItem()
            self.plot.addItem(self.line)
            self.plot.addItem(self.scatter)

            self.hint = QLabel(LEGEND_TEXT)
            self.hint.setTextFormat(Qt.TextFormat.RichText)
            self.hint.setWordWrap(True)
            lay.addWidget(self.hint)

            preset_row = QHBoxLayout()
            preset_row.addWidget(QLabel("Vorlage:"))
            self.preset_buttons: list[QPushButton] = []
            for name, pts in PRESETS:
                b = QPushButton(name)
                b.setToolTip(f"Kurve auf '{name}' setzen (mit 'Anwenden' bestätigen)")
                b.clicked.connect(lambda _=False, p=pts: self.apply_preset(p))
                preset_row.addWidget(b)
                self.preset_buttons.append(b)
            lay.addLayout(preset_row)

            self.user_preset_row = QHBoxLayout()
            self.user_preset_row.addWidget(QLabel("Eigene:"))
            self.user_preset_buttons: list[QPushButton] = []
            self.user_preset_delete_buttons: list[QPushButton] = []
            self._user_presets: dict[str, tuple[list[tuple[float, int]], list[str]]] = {}
            lay.addLayout(self.user_preset_row)

            row = QHBoxLayout()
            self.apply_btn = QPushButton("Anwenden")
            self.apply_btn.clicked.connect(self.commit)
            row.addWidget(self.apply_btn)
            self.save_as_btn = QPushButton("Speichern als …")
            self.save_as_btn.clicked.connect(self._on_save_as)
            row.addWidget(self.save_as_btn)
            lay.addLayout(row)

            self._dragging = False
            self._drag_filter = _DragFilter(self)
            try:
                self.plot.scene().installEventFilter(self._drag_filter)
                self.plot.scene().sigMouseClicked.connect(self._on_click)
                self.plot.scene().sigMouseMoved.connect(self._on_hover)
            except Exception:
                pass

            self.refresh()

        def refresh(self):
            ts = [p[0] for p in model.points]
            ls = [p[1] for p in model.points]
            self.scatter.setData(x=ts, y=ls)
            self.line.setData(x=ts, y=ls)

        def _hit_test(self, scene_pos) -> int | None:
            vb = self.plot.plotItem.vb
            best: int | None = None
            best_d = float(HIT_THRESHOLD_PX)
            for i, (t, lvl) in enumerate(model.points):
                p_scene = vb.mapViewToScene(QPointF(float(t), float(lvl)))
                dx = p_scene.x() - scene_pos.x()
                dy = p_scene.y() - scene_pos.y()
                d = (dx * dx + dy * dy) ** 0.5
                if d < best_d:
                    best_d = d
                    best = i
            return best

        def _drag_to(self, idx: int, scene_pos):
            vb = self.plot.plotItem.vb
            pt = vb.mapSceneToView(scene_pos)
            try:
                model.move(idx, float(pt.x()), float(pt.y()))
            except (IndexError, ValueError):
                return
            self.refresh()

        @staticmethod
        def _format_point_tooltip(t: float, lvl: int) -> str:
            return f"{float(t):.1f} °C → Level {int(lvl)}"

        def _on_hover(self, scene_pos):
            from PyQt6.QtWidgets import QToolTip
            from PyQt6.QtGui import QCursor
            idx = self._hit_test(scene_pos)
            if idx is None:
                return
            t, lvl = model.points[idx]
            QToolTip.showText(QCursor.pos(),
                              self._format_point_tooltip(t, lvl), self.plot)

        def _on_click(self, ev):
            if self._dragging:
                # Click direkt nach Drag-Release ignorieren
                self._dragging = False
                return
            try:
                vb = self.plot.plotItem.vb
                pos = ev.scenePos()
                pt = vb.mapSceneToView(pos)
                t = float(pt.x())
                lvl = float(pt.y())
            except Exception:
                return
            if ev.button() == Qt.MouseButton.RightButton:
                if not model.points:
                    return
                idx = self._hit_test(pos)
                if idx is None:
                    return
                try:
                    model.remove(idx)
                except ValueError:
                    return
                self.refresh()
            elif ev.button() == Qt.MouseButton.LeftButton:
                try:
                    model.add(t, int(round(lvl)))
                except ValueError:
                    return
                self.refresh()

        def apply_preset(self, points: list[tuple[float, int]]) -> None:
            model.points = [(float(t), int(l)) for t, l in points]
            self.refresh()

        def commit(self):
            on_change(list(model.points))

        def set_user_presets(self, presets: dict) -> None:
            for b in self.user_preset_buttons + self.user_preset_delete_buttons:
                self.user_preset_row.removeWidget(b)
                b.deleteLater()
            self.user_preset_buttons = []
            self.user_preset_delete_buttons = []
            self._user_presets = dict(presets)
            for name, (pts, _sensors) in presets.items():
                b = QPushButton(name)
                b.setToolTip(f"Eigenes Preset '{name}' laden")
                b.clicked.connect(lambda _=False, p=list(pts): self.apply_preset(p))
                self.user_preset_row.addWidget(b)
                self.user_preset_buttons.append(b)
                d = QPushButton("×")
                d.setToolTip(f"Preset '{name}' löschen")
                d.setMaximumWidth(24)
                d.clicked.connect(lambda _=False, n=name: self._on_delete(n))
                self.user_preset_row.addWidget(d)
                self.user_preset_delete_buttons.append(d)

        def _on_save_as(self) -> None:
            name, ok = QInputDialog.getText(self, "Preset speichern", "Name:")
            if not ok or not name:
                return
            if name in _BUILTIN_NAMES:
                QMessageBox.warning(self, "tpfan",
                    f"'{name}' ist ein vordefiniertes Preset und kann nicht überschrieben werden.")
                return
            if on_save_preset is not None:
                on_save_preset(name, list(model.points))

        def _on_delete(self, name: str) -> None:
            answer = QMessageBox.question(self, "Preset löschen",
                f"Preset '{name}' wirklich löschen?")
            if answer != QMessageBox.StandardButton.Yes:
                return
            if on_delete_preset is not None:
                on_delete_preset(name)

    return CurveEditor(parent)
